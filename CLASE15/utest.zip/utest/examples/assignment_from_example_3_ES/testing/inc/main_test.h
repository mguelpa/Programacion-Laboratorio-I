void startTesting(int testGroup);
