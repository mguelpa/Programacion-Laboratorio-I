#ifndef LIB_H_INCLUDED
#define LIB_H_INCLUDED
#define CANT_EMPLEADOS 5

int obtenerDatos (int edad[], float sueldo[]);
int mostrarDatos(int edad[], float salario[]);


#endif // LIB_H_INCLUDED
