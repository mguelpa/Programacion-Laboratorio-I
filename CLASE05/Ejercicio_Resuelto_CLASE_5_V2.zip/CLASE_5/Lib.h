#ifndef LIB_H_INCLUDED
#define LIB_H_INCLUDED


#endif // LIB_H_INCLUDED
int obtenerDatos (int edad[], float sueldo[], int qtyMaxima);
int mostrarDatos(int edad[], float salario[], int qtyMaxima);
int calcularMaximo(float salario[], int qtyMaxima);
int calcularPromedio(int edad[], int qtyMaxima, float* promedio);
