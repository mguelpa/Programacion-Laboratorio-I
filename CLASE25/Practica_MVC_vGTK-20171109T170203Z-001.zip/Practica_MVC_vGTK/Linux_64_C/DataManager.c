#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "Socio.h"

