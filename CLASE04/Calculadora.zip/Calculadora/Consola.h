#ifndef CONSOLA_H_INCLUDED
#define CONSOLA_H_INCLUDED

int tomaNumero(char msg[], float *x, float max, float min );

#endif // CONSOLA_H_INCLUDED
