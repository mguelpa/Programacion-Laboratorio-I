#ifndef LLAMADA_H_INCLUDED
#define LLAMADA_H_INCLUDED

    #define LLAMADA_EMPTY 0
    #define LLAMADA_USED 1

    #define FALLA_3G 0
    #define FALLA_LTE 1
    #define FALLA_EQUIPO 2

    #define ENCURSO 0
    #define SOLUCIONADO 1
    #define NOSOLUCIONADO 2

    typedef struct
    {
        int idLlamada;
        int idAbonado;
        int motivo;
        int estado;
        int tiempo;
        int flagEstado;

    }sLlamada;

#endif // LLAMADA_H_INCLUDED


int llamadas_init(sLlamada* pLlamadas, int length);

int llamadas_open(sLlamada* pLlamadas, int length, int idAbonado, int motivo);
int llamadas_close(sLlamada* pLlamadas, int length, int idLlamada, int estado, int tiempo);

sLlamada* llamadas_find(sLlamada* pLlamadas, int length, int idLlamada);



