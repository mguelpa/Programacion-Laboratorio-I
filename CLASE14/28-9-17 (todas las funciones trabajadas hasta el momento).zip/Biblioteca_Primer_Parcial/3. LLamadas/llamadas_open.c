#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string.h>

#include "llamada.h"

#define LLAMADA_EMPTY 0
#define LLAMADA_USED 1

#define FALLA_3G 0
#define FALLA_LTE 1
#define FALLA_EQUIPO 2

#define ENCURSO 0
#define SOLUCIONADO 1
#define NOSOLUCIONADO 2

typedef struct
{
    int idLlamada;
    int idAbonado;
    int motivo;
    int estado;
    int tiempo;
    int flagEstado;

}sLlamada;

///////////////////////////////////////////////////////////////////////////////
int llamadas_open(sLlamada* pLlamadas, int length, int idAbonado, int motivo)
{

    int retorno=-1;
    int id,index;
    if(pLlamadas != NULL && length > 0)
    {
        index = llamadas_findEmptyPlace(pLlamadas, length);
        if(index != -1)
        {
            id = llamadas_findNextId(pLlamadas, length);
            (pLlamadas+index)->estado = ENCURSO;
            (pLlamadas+index)->idLlamada = id;
            (pLlamadas+index)->idAbonado = idAbonado;
            (pLlamadas+index)->motivo = motivo;
            (pLlamadas+index)->tiempo = 0;
            (pLlamadas+index)->flagEstado = LLAMADA_USED;
            retorno=0;
        }
    }
    return retorno;
}
///////////////////////////////////////////////////////////////////////////////