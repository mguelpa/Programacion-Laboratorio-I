#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string.h>

#include "llamada.h"

static int llamadas_findEmptyPlace(sLlamada* pLlamadas, int length);
static int llamadas_findNextId(sLlamada* pLlamadas, int length);
//__________________________________________________________________

///////////////////////////////////////////////////////////////////////////////
int llamadas_init(sLlamada* pLlamadas, int length)
{
    int i;
    int retorno=-1;
    if(pLlamadas != NULL && length > 0)
    {
        for(i=0;i<length;i++)
        {
            (pLlamadas+i)->flagEstado = LLAMADA_EMPTY;
        }
        retorno = 0;
    }
    return retorno;
}
///////////////////////////////////////////////////////////////////////////////
int llamadas_open(sLlamada* pLlamadas, int length, int idAbonado, int motivo)
{

    int retorno=-1;
    int id,index;
    if(pLlamadas != NULL && length > 0)
    {
        index = llamadas_findEmptyPlace(pLlamadas, length);
        if(index != -1)
        {
            id = llamadas_findNextId(pLlamadas, length);
            (pLlamadas+index)->estado = ENCURSO;
            (pLlamadas+index)->idLlamada = id;
            (pLlamadas+index)->idAbonado = idAbonado;
            (pLlamadas+index)->motivo = motivo;
            (pLlamadas+index)->tiempo = 0;
            (pLlamadas+index)->flagEstado = LLAMADA_USED;
            retorno=0;
        }
    }
    return retorno;
}
///////////////////////////////////////////////////////////////////////////////
sLlamada* llamadas_find(sLlamada* pLlamadas, int length, int idLlamada)
{
    sLlamada* pRetorno = NULL;
    int i;
    if(pLlamadas != NULL && length > 0)
    {
        for(i=0;i<length;i++)
        {
            if((pLlamadas+i)->idLlamada == idLlamada && (pLlamadas+i)->flagEstado == LLAMADA_USED)
            {
                pRetorno = (pLlamadas+i);
                break;
            }
        }
    }
    return pRetorno;
}
///////////////////////////////////////////////////////////////////////////////
int llamadas_close(sLlamada* pLlamadas, int length, int idLlamada, int estado, int tiempo)
{
    int retorno=-1;
    sLlamada* pAuxLlamada;

    if(pLlamadas != NULL && length > 0)
    {
        pAuxLlamada = llamadas_find(pLlamadas, length,idLlamada);
        if(pAuxLlamada != NULL)
        {
            pAuxLlamada->estado = estado;
            pAuxLlamada->tiempo = tiempo;
            retorno=0;
        }
    }
    return retorno;
}
///////////////////////////////////////////////////////////////////////////////
static int llamadas_findEmptyPlace(sLlamada* pLlamadas, int length)
{
    int i;
    int retorno=-1;
    if(pLlamadas != NULL && length > 0)
    {
        for(i=0;i<length;i++)
        {
            if((pLlamadas+i)->flagEstado == LLAMADA_EMPTY)
            {
                retorno = i;
                break;
            }
        }

    }
    return retorno;
}
///////////////////////////////////////////////////////////////////////////////
static int llamadas_findNextId(sLlamada* pLlamadas, int length)
{
    int i, maxId=-1;
    int retorno=-1;
    if(pLlamadas != NULL && length > 0)
    {
        for(i=0;i<length;i++)
        {
            if((pLlamadas+i)->flagEstado == LLAMADA_USED )
            {
                if((pLlamadas+i)->idLlamada > maxId || maxId == -1)
                    maxId = (pLlamadas+i)->idLlamada;
            }
        }
        retorno = maxId+1;
    }
    return retorno;
}
///////////////////////////////////////////////////////////////////////////////

