#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string.h>

#include "llamada.h"

#define LLAMADA_EMPTY 0
#define LLAMADA_USED 1

#define FALLA_3G 0
#define FALLA_LTE 1
#define FALLA_EQUIPO 2

#define ENCURSO 0
#define SOLUCIONADO 1
#define NOSOLUCIONADO 2

typedef struct
{
    int idLlamada;
    int idAbonado;
    int motivo;
    int estado;
    int tiempo;
    int flagEstado;

}sLlamada;

///////////////////////////////////////////////////////////////////////////////
int llamadas_init(sLlamada* pLlamadas, int length)
{
    int i;
    int retorno=-1;
    if(pLlamadas != NULL && length > 0)
    {
        for(i=0;i<length;i++)
        {
            (pLlamadas+i)->flagEstado = LLAMADA_EMPTY;
        }
        retorno = 0;
    }
    return retorno;
}
///////////////////////////////////////////////////////////////////////////////