#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "abonado.h"

#define ABONADO_EMPTY 0
#define ABONADO_USED 1
#define ABONADO_DELETE 2

typedef struct
{
    unsigned int idAbonado;
    unsigned int numero;
    char nombre[50];
    char apellido[50];
    int flagEstado;

}sAbonado;

///////////////////////////////////////////////////////////
int abonados_update(sAbonado* pAbonados, int length, int idAbonado, char* nombre, char* apellido)
{
    int retorno=-1;
    sAbonado* pAuxAbonado;

    if(pAbonados != NULL && length > 0)
    {
        pAuxAbonado = abonados_find(pAbonados, length,idAbonado);
        if(pAuxAbonado != NULL)
        {
            strcpy(pAuxAbonado->nombre,nombre);
            strcpy(pAuxAbonado->apellido,apellido);
            retorno=0;
        }
    }
    return retorno;
}
///////////////////////////////////////////////////////////