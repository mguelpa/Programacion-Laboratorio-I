#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "abonado.h"

#define ABONADO_EMPTY 0
#define ABONADO_USED 1
#define ABONADO_DELETE 2

typedef struct
{
    unsigned int idAbonado;
    unsigned int numero;
    char nombre[50];
    char apellido[50];
    int flagEstado;

}sAbonado;

///////////////////////////////////////////////////////////
int abonados_append(sAbonado* pAbonados, int length, int numero, char nombre[],char apellido[])
{

    int retorno = -1;
    int id, index;
    if(pAbonados != NULL && length > 0)
    {
        index = abonados_findEmptyPlace(pAbonados, length);
        if(index != -1)
        {
            id = abonados_findNextId(pAbonados, length);
            strcpy((pAbonados+index)->nombre,nombre);
            strcpy((pAbonados+index)->apellido,apellido);
            (pAbonados+index)->numero = numero;
            (pAbonados+index)->idAbonado = id;
            
            (pAbonados+index)->flagEstado = ABONADO_USED;
            retorno=0;
        }
    }
    return retorno;
}
///////////////////////////////////////////////////////////