#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "abonado.h"

#define ABONADO_EMPTY 0
#define ABONADO_USED 1
#define ABONADO_DELETE 2

typedef struct
{
    unsigned int idAbonado;
    unsigned int numero;
    char nombre[50];
    char apellido[50];
    int flagEstado;

}sAbonado;

///////////////////////////////////////////////////////////
sAbonado* abonados_find(sAbonado* pAbonados, int length, int idAbonado)
{
    sAbonado* pRetorno = NULL;
    int i;
    if(pAbonados != NULL && length > 0)
    {
        for(i=0;i<length;i++)
        {
            if((pAbonados+i)->idAbonado == idAbonado && (pAbonados+i)->flagEstado == ABONADO_USED)
            {
                pRetorno = (pAbonados+i);
                break;
            }
        }
    }
    return pRetorno;
}
///////////////////////////////////////////////////////////