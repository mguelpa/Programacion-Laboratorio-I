#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "abonado.h"

#define ABONADO_EMPTY 0
#define ABONADO_USED 1
#define ABONADO_DELETE 2

typedef struct
{
    unsigned int idAbonado;
    unsigned int numero;
    char nombre[50];
    char apellido[50];
    int flagEstado;

}sAbonado;

///////////////////////////////////////////////////////////
static int abonados_findNextId(sAbonado* pAbonados, int length)
{
    int i, maxId=-1;
    int retorno=-1;
    if(pAbonados != NULL && length > 0)
    {
        for(i=0;i<length;i++)
        {
            if((pAbonados+i)->flagEstado == ABONADO_USED || (pAbonados+i)->flagEstado == ABONADO_DELETE)
            {
                if((pAbonados+i)->idAbonado > maxId || maxId == -1)
                    maxId = (pAbonados+i)->idAbonado;
            }
        }
        retorno = maxId+1;
    }
    return retorno;
}
///////////////////////////////////////////////////////////