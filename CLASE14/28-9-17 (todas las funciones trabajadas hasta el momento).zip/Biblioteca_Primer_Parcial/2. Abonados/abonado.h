#ifndef ABONADO_H_INCLUDED
#define ABONADO_H_INCLUDED

    #define ABONADO_EMPTY 0
    #define ABONADO_USED 1
    #define ABONADO_DELETE 2

    typedef struct
    {
        unsigned int idAbonado;
        unsigned int numero;
        char nombre[50];
        char apellido[50];
        int flagEstado;

    }sAbonado;

#endif //ABONADO_H_INCLUDED


int abonados_init(sAbonado* pAbonados, int length);

int abonados_remove(sAbonado* pAbonados, int length, int idAbonado);
int abonados_update(sAbonado* pAbonados, int length, int idAbonado, char* nombre, char* apellido);
int abonados_append(sAbonado* pAbonados, int length, int numero, char nombre[],char apellido[]);

sAbonado* abonados_find(sAbonado* pAbonados, int length, int idAbonado);
