#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "abonado.h"

#define ABONADO_EMPTY 0
#define ABONADO_USED 1
#define ABONADO_DELETE 2

typedef struct
{
    unsigned int idAbonado;
    unsigned int numero;
    char nombre[50];
    char apellido[50];
    int flagEstado;

}sAbonado;

///////////////////////////////////////////////////////////
int abonados_remove(sAbonado* pAbonados, int length, int idAbonado)
{
    sAbonado* pAuxAbonado;
    int retorno = -1;

    pAuxAbonado = abonados_find(pAbonados, length, idAbonado);
    if(pAuxAbonado != NULL)
    {
        pAuxAbonado->flagEstado = ABONADO_DELETE;
        retorno = 0;
    }

    return retorno;
}
///////////////////////////////////////////////////////////