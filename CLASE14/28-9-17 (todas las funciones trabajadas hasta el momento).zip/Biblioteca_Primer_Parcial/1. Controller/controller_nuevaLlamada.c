#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


#include "utn.h"
#include "abonado.h"
#include "llamada.h"

#define CANTIDAD_TIPOS_RECLAMO 3
#define RECLAMOS 50

///////////////////////////////////////////////////////////////////////////////
int controller_nuevaLlamada(sLlamada* pLlamadas, int lengthLlamada ,sAbonado* pAbonados, int lengthAbonado)
{
    int id, motivo;

    int retorno=-1;

    clearScreen();
    retorno = getValidInt("\nID del Abonado ","\nRango valido 0-999", &id,0,9999,3);

    if(retorno == 0)
    {
        if(abonados_find(pAbonados, lengthAbonado, id) == NULL)
        {
            printf("El abonado elegido no existe\n");
            pause();

        }
        else
        {
            retorno = getValidInt("\nMotivo:\n  Falla 3g [0]\n  Falla LTE [1]\n  Falla Equipo [2]\n Opcion:  ","\nRango valido 0-2", &motivo,0,2,3);
            if(retorno == 0)
            {
                llamadas_open(pLlamadas, lengthLlamada,id, motivo);
            }
        }
    }
    return retorno;
}
///////////////////////////////////////////////////////////////////////////////