#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


#include "utn.h"
#include "abonado.h"
#include "llamada.h"

#define CANTIDAD_TIPOS_RECLAMO 3
#define RECLAMOS 50

///////////////////////////////////////////////////////////////////////////////
int controller_informeReclamosTiempos(sLlamada* pLlamadas, int lengthLlamada)
{
    int retorno=-1,i, maximoReclamo,maximoTiempoPromedioReclamo;
    int reclamosOcurrencia[CANTIDAD_TIPOS_RECLAMO];
    int reclamosTiempoAcumulado[CANTIDAD_TIPOS_RECLAMO]; // Uso el indice segun tipo de reclamo
    float reclamosTiempoPromedio[CANTIDAD_TIPOS_RECLAMO];

    for(i=0;i<CANTIDAD_TIPOS_RECLAMO;i++)
    {
        reclamosOcurrencia[i] = 0;
        reclamosTiempoAcumulado[i] = 0;
        reclamosTiempoPromedio[i] = 0;
    }

    if(pLlamadas != NULL && lengthLlamada > 0)
    {
        clearScreen();
        for(i=0;i<lengthLlamada;i++)
        {
            if( ((pLlamadas+i)->flagEstado == LLAMADA_USED) && (((pLlamadas+i)->estado) == SOLUCIONADO || ((pLlamadas+i)->estado) == NOSOLUCIONADO))
            {
                reclamosOcurrencia[(pLlamadas+i)->motivo]++;
                reclamosTiempoAcumulado[(pLlamadas+i)->motivo] = reclamosTiempoAcumulado[(pLlamadas+i)->motivo] + (pLlamadas+i)->tiempo;
            }
        }
        printf("*************************************************************\n");
        printf("**************** SOLO RECLAMOS FINALIZADOS ******************\n");
        printf("*************************************************************\n");
        printf("%15s - %8s - %8s- %11s\n","Tipo Reclamo","Cantidad", "Tiempo", "Promedio");
        maximoReclamo = 0;
        maximoTiempoPromedioReclamo = 0;
        for(i=0;i<CANTIDAD_TIPOS_RECLAMO;i++)
        {
            reclamosTiempoPromedio[i] = (float)reclamosTiempoAcumulado[i] / (float)reclamosOcurrencia[i];
            if(reclamosTiempoPromedio[i] > reclamosTiempoPromedio[maximoTiempoPromedioReclamo]) maximoTiempoPromedioReclamo = i;
            if(reclamosOcurrencia[i] > reclamosOcurrencia [maximoReclamo]) maximoReclamo = i;
            printf("%15s - %8d - %8d - %8.2f\n",motivoLlamada[i],reclamosOcurrencia[i],reclamosTiempoAcumulado[i],reclamosTiempoPromedio[i]);
        }
        printf("\nReclamo con mayor ocurrencia: %s\n",motivoLlamada[maximoReclamo]);
        printf("Reclamo que mas demora en ser atendido: %s\n",motivoLlamada[maximoTiempoPromedioReclamo]);
        printf("*************************************************************\n");
        printf("*************************************************************\n");
        pause();

        retorno = 0;
    }
    return retorno;

}
///////////////////////////////////////////////////////////////////////////////