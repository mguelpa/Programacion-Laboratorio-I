#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


#include "utn.h"
#include "abonado.h"
#include "llamada.h"

#define CANTIDAD_TIPOS_RECLAMO 3
#define RECLAMOS 50

///////////////////////////////////////////////////////////////////////////////
int controller_cerrarLlamada(sLlamada* pLlamadas, int length)
{
    int id, tiempo,estado;
    sLlamada* pAuxLlamada;

    int retorno=-1;

    clearScreen();
    retorno = getValidInt("\nID de la llamada ","\nRango valido 0-9999", &id,0,9999,3);

    if(retorno == 0)
    {
        pAuxLlamada = llamadas_find(pLlamadas, length, id);
        if(pAuxLlamada == NULL)
        {
            printf("La llamada no existe\n");
            pause();

        }
        else if(pAuxLlamada->estado != ENCURSO)
        {
            printf("Solo se pueden finalizar llamadas en curso\n");
            pause();
        }
        else
        {
            retorno = getValidInt("\nTiempo insumido [minutos] :","\nRango valido 0-600", &tiempo,0,600,3);
            if(retorno == 0)
            {
                retorno = getValidInt("\nEstado de Cierre:\n  Resuelto [1]\n  No Resuelto [2]\n\n Opcion:  ","\nRango valido 1-2", &estado,0,1,3);
                if(retorno == 0)
                {
                    llamadas_close(pLlamadas, length,id, estado, tiempo);
                }
            }
        }
    }
    return retorno;
}
///////////////////////////////////////////////////////////////////////////////