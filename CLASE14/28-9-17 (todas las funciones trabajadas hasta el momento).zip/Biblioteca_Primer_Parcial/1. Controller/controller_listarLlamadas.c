#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


#include "utn.h"
#include "abonado.h"
#include "llamada.h"

#define CANTIDAD_TIPOS_RECLAMO 3
#define RECLAMOS 50

///////////////////////////////////////////////////////////////////////////////
int controller_listarLlamadas(sLlamada* pLlamadas, int length)
{
    int retorno=-1,i;
    if(pLlamadas != NULL && length > 0)
    {
        clearScreen();
        printf("\n\n%4s - %8s - %-12s - %-12s- %8s\n"," ID","  ID AB","MOTIVO","ESTADO","TIEMPO");
        for(i=0;i<length;i++)
        {
            if((pLlamadas+i)->flagEstado == LLAMADA_USED)
                printf("%4d - %8d - %-12s - %-12s - %8d\n",(pLlamadas+i)->idLlamada,(pLlamadas+i)->idAbonado,motivoLlamada[(pLlamadas+i)->motivo],estadoLlamada[(pLlamadas+i)->estado],(pLlamadas+i)->tiempo);
        }
        retorno = 0;
    }
    return retorno;
}
///////////////////////////////////////////////////////////////////////////////