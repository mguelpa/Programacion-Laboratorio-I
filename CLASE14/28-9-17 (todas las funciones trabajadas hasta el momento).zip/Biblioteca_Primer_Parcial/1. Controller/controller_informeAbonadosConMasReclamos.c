#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


#include "utn.h"
#include "abonado.h"
#include "llamada.h"

#define CANTIDAD_TIPOS_RECLAMO 3
#define RECLAMOS 50

///////////////////////////////////////////////////////////////////////////////
int controller_informeAbonadosConMasReclamos(sLlamada* pLlamadas, int lengthLlamada ,sAbonado* pAbonados, int lengthAbonado)
{
    int retorno=-1,i, maximoReclamo=0;
    int reclamosArray[RECLAMOS]; // Uso el indice para el id de Abonado y el valor como acumulador de reclamos
    sAbonado* auxAbonado;

    for(i=0;i<RECLAMOS;i++)
    {
        reclamosArray[i] = 0;
    }

    if(pLlamadas != NULL && lengthLlamada > 0 && pAbonados != NULL && lengthAbonado > 0)
    {
        clearScreen();
        for(i=0;i<lengthLlamada;i++)
        {
            if((pLlamadas+i)->flagEstado == LLAMADA_USED)
            {
                reclamosArray[(pLlamadas+i)->idAbonado]++;
            }
        }
        for(i=0;i<RECLAMOS;i++)
        {
            if(reclamosArray[i] > maximoReclamo)
            {
                maximoReclamo = reclamosArray[i];
            }
        }
        printf("*************************************************************\n");
        printf("**************** ABONADOS CON MAS RECLAMOS ******************\n");
        printf("*************************************************************\n");
        for(i=0;i<RECLAMOS;i++)
        {
            if(reclamosArray[i] == maximoReclamo)
            {
                auxAbonado = abonados_find(pAbonados, lengthAbonado, i);
                printf("NOMBRE: %-14s  APELLIDO: %-14s  RECLAMOS:%2d\n",auxAbonado->nombre,auxAbonado->apellido,maximoReclamo);
                printf("*************************************************************\n");
            }
        }
        printf("*************************************************************\n");
        pause();

        retorno = 0;
    }
    return retorno;

}
///////////////////////////////////////////////////////////////////////////////