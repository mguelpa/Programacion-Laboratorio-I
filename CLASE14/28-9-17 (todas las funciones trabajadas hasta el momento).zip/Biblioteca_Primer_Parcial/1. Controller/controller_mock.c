#define CANTIDAD_TIPOS_RECLAMO 3
#define RECLAMOS 50

///////////////////////////////////////////////////////////////////////////////
void controller_mock(sLlamada* pLlamadas, int lengthLlamada ,sAbonado* pAbonados, int lengthAbonado)
{
    abonados_append(pAbonados,lengthAbonado, 2226465,"JUAN", "PEREZ");
    abonados_append(pAbonados,lengthAbonado, 2226466,"LUCAS", "GONZALES");
    abonados_append(pAbonados,lengthAbonado, 2226467,"PEDRO", "LOPEZ");

    llamadas_open(pLlamadas, lengthLlamada, 0, FALLA_3G);
    llamadas_open(pLlamadas, lengthLlamada, 0, FALLA_LTE);
    llamadas_open(pLlamadas, lengthLlamada, 1, FALLA_EQUIPO);
    llamadas_open(pLlamadas, lengthLlamada, 1, FALLA_EQUIPO);
    llamadas_open(pLlamadas, lengthLlamada, 2, FALLA_EQUIPO);

    llamadas_close(pLlamadas, lengthLlamada,0, SOLUCIONADO, 1000);
    llamadas_close(pLlamadas, lengthLlamada,1, SOLUCIONADO, 100);
    llamadas_close(pLlamadas, lengthLlamada,2, SOLUCIONADO, 200);
    llamadas_close(pLlamadas, lengthLlamada,3, SOLUCIONADO, 100);
    llamadas_close(pLlamadas, lengthLlamada,4, NOSOLUCIONADO, 90);
}
///////////////////////////////////////////////////////////////////////////////