#include "abonado.h"
#include "llamada.h"

#ifndef CONTROLER_H_INCLUDED
#define CONTROLER_H_INCLUDED


#endif // CONTROLER_H_INCLUDED



void controller_mock(sLlamada* pLlamadas, int lengthLlamada ,sAbonado* pAbonados, int lengthAbonado);


int controller_altaAbonado(sAbonado* pAbonados, int length);
int controller_modificarAbonado(sAbonado* pAbonados, int length);
int controller_bajaAbonado(sAbonado* pAbonados, int length);


int controller_nuevaLlamada(sLlamada* pLlamadas, int lengthLlamada ,sAbonado* pAbonados, int lengthAbonado);
int controller_cerrarLlamada(sLlamada* pLlamadas, int length);


int controller_listarAbonados(sAbonado* pAbonados, int length);
int controller_listarLlamadas(sLlamada* pLlamadas, int length);


int controller_informeAbonadosConMasReclamos(sLlamada* pLlamadas, int lengthLlamada ,sAbonado* pAbonados, int lengthAbonado);
int controller_informeReclamosTiempos(sLlamada* pLlamadas, int lengthLlamada);
