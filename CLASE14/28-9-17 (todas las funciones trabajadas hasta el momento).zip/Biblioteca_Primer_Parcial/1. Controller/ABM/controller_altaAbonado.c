#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


#include "utn.h"
#include "abonado.h"
#include "llamada.h"

#define CANTIDAD_TIPOS_RECLAMO 3
#define RECLAMOS 50

///////////////////////////////////////////////////////////////////////////////
int controller_altaAbonado(sAbonado* pAbonados, int length)
{
    char nombre[50];
    char apellido[50];
    int numero;
    int retorno=-1;

    system("clear");
    retorno = getValidString("\nNombre: ","\nNo es un nombre valido","\nLongitud maxima 50", nombre,50,3);
    if(retorno == 0)
    {
        retorno = getValidString("\nApellido: ","\nNo es un apellido valido","\nLongitud maxima 50", apellido,50,3);
        if(retorno == 0)
        {
            retorno = getValidInt("\nNumero: ","\nRango valido 100000 - 10000000", &numero,100000,10000000,3);
            if(retorno == 0)
            {
                retorno = abonados_append(pAbonados, length, numero, nombre, apellido);
            }
        }
    }
    return retorno;
}
///////////////////////////////////////////////////////////////////////////////