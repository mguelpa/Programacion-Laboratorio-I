#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


#include "utn.h"
#include "abonado.h"
#include "llamada.h"

#define CANTIDAD_TIPOS_RECLAMO 3
#define RECLAMOS 50

///////////////////////////////////////////////////////////////////////////////
int controller_modificarAbonado(sAbonado* pAbonados, int length)
{
    char nombre[50];
    char apellido[50];
    int id;

    int retorno=-1;

    clearScreen();
    retorno = getValidInt("\nID a Modificar: ","\nRango valido 0-999", &id,0,9999,3);

    if(retorno == 0)
    {
        if(abonados_find(pAbonados, length, id) == NULL)
        {
            printf("El abonado elegido no existe\n");
            pause();

        }
        else
        {
            retorno = getValidString("\nNombre: ","\nNo es un nombre valido","\nLongitud maxima 50", nombre,50,3);
            if(retorno == 0)
            {
                retorno = getValidString("\nApellido: ","\nNo es un apellido valido","\nLongitud maxima 50", apellido,50,3);
                if(retorno == 0)
                {
                    retorno = abonados_update(pAbonados, length, id, nombre, apellido);
                }
            }
        }
    }
    return retorno;
}
///////////////////////////////////////////////////////////////////////////////