#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


#include "utn.h"
#include "abonado.h"
#include "llamada.h"

#define CANTIDAD_TIPOS_RECLAMO 3
#define RECLAMOS 50

///////////////////////////////////////////////////////////////////////////////
int controller_listarAbonados(sAbonado* pAbonados, int length)
{
    int retorno=-1,i;
    if(pAbonados != NULL && length > 0)
    {
        clearScreen();
        printf("\n\n%4s - %-20s - %-20s - %-8s\n"," ID","    NOMBRE","    APELLIDO","   NUMERO");
        for(i=0;i<length;i++)
        {
            if((pAbonados+i)->flagEstado == ABONADO_USED)
                printf("%4d - %-20s - %-20s - %-8d\n",(pAbonados+i)->idAbonado,(pAbonados+i)->nombre,(pAbonados+i)->apellido,(pAbonados+i)->numero);
        }
        retorno = 0;
    }
    return retorno;
}
///////////////////////////////////////////////////////////////////////////////