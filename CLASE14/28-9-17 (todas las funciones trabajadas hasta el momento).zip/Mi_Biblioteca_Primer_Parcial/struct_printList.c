/********************************************************************
 * \brief   Funcion utilizada para imprimir el listado de los datos
 *          cargados en el array estructura con status cargado
 *          (STATUS_LOADED), de lo contrario imprime un mensaje error
 *
 * \param   1. Puntero al array a imprimir.
 * \param   2. Limite del array.
 *
 * \return  ( 0) =  impresion exitosa.
 * \return  (-1) =  aun no se han cargado datos.
 * \return  (-2) =  error en los parametros ingresados.
 *
 */
    int struct_printList (sPersona* arrayAlumnos, int length)
    {
        int i;
        int retorno = -1;

        if(arrayAlumnos != NULL && length > 0)
        {
            for(i = 0; i<length; i++)
            {
                if(arrayAlumnos[i].status == STATUS_LOADED)
                {
                    printf("---------------------------------------------\n");

                    printf("Nombre: %s\n", arrayAlumnos[i].nombre);
                    printf("Edad: %d\n", arrayAlumnos[i].edad);
                    printf("DNI: %s\n", arrayAlumnos[i].dni);
                    //printf("Estado: %d\n\n", arrayAlumnos[index].status);
                    printf("\n");
                    retorno = 0;
                }
            }
        }else{retorno = -2;}

        return retorno;
    }