#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


#include "validate.h"
#include "asociado.h"
#include "llamada.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int command_modificarAsociado (sNombre_struct* nombre_array, int length)
    int retorno = -1;

    int  id;
    char auxData1[MAX_CHARS_NOMBRES]; // nomnbre
    char auxData2[MAX_CHARS_NOMBRES]; // apellido
    char auxData3[MAX_CHARS_DNI];     // dni
    int  auxData4;                    // edad
  //sNombre_struct nombre_datostruct;

if(nombre_array != NULL && length > 0)
{
    id = gedata_getInt("ingrese ID a Modificar: ", "ha ingresado caracteres invalidos.\n", "fuera de rango.\n", 3, 0, 999, &id);

    if(asoc_searchIndexById(nombre_array, length, id) == 0)
    {
        if(val_getNames(auxData1, MAX_CHARS_NOMBRES, "Ingrese el nombre: ", "Ha ingresado caracteres no validos.", MAX_INTENTOS_REINGRESOS) == 0)
        {
            if(val_getNames(auxData2, MAX_CHARS_NOMBRES, "Ingrese el apellido: ", "Ha ingresado caracteres no validos.", MAX_INTENTOS_REINGRESOS) == 0)
            {
                if(val_getAge(auxData4, MAX_CHARS_EDAD, "Ingrese la edad: ", "Ha ingresado caracteres no validos.", MAX_INTENTOS_REINGRESOS) == 0)
                {
                    if(val_getDNI(auxData3, MAX_CHARS_DNI, "Ingrese el Nro de DNI: ", "Ha ingresado caracteres no validos.", MAX_INTENTOS_REINGRESOS) == 0)
                    {
                        asociados_updateData(nombre_array, length, id, auxData1, auxData2, auxData3, auxData4);
                    }
                }
            }
        }
    }else{printf("El ID ingresado no corresponde a ningun asociado\n");}

    return retorno;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
