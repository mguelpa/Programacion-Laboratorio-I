///////////////////////////////////////////////////////////////////////////////
int command_downAsoc (sNombre_struct* nombre_array, int length)
{
    int retorno = -1;
    int id = 0;

    id = gedata_getInt("ingrese ID a dar de Baja: ", "ha ingresado caracteres invalidos.\n", "fuera de rango.\n", 3, 0, 999, &id);

    if(asoc_searchIndexById(nombre_array, length, id) == 0){
        asoc_downData(nombre_array, length, id);
        retorno = 0;
    }
    else{
        printf("El ID ingresado no corresponde a ningun asociado\n");
    }
    return retorno;
}
///////////////////////////////////////////////////////////////////////////////