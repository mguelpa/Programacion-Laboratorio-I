#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "asociado.h"

#define STATUS_EMPTY 0
#define STATUS_LOADED 1
#define STATUS_DOWN -1

typedef struct
{
    unsigned int id;
    unsigned int status; //(STATUS_EMPTY 0) (STATUS_LOADED 1) (STATUS_DOWN -1)

    char nombre[51];
    char apellido[51];
    int  edad;
    char dni[51];

}sAsociados;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int command_loadSlot (sNombre_struct* nombre_array, int length)
{
    int retorno;
    char respuesta = 'n';
    int i = 0;

    unsigned int id;
    int index;
    
    char auxData1[MAX_CHARS_NOMBRES]; // nomnbre
    char auxData2[MAX_CHARS_NOMBRES]; // apellido
    char auxData3[MAX_CHARS_DNI];     // dni
    int  auxData4;                    // edad
  //sNombre_struct nombre_datostruct;

    do
    {
        if(getdata_getName(auxData1, MAX_CHARS_NOMBRES, "Ingrese el nombre: ", "Ha ingresado caracteres no validos.", MAX_INTENTOS_REINGRESOS) == 0)
        {
            if(getdata_getName(auxData2, MAX_CHARS_NOMBRES, "Ingrese el apellido: ", "Ha ingresado caracteres no validos.", MAX_INTENTOS_REINGRESOS) == 0)
            {
                if(getdata_getInt("ingrese un numero: ", "ha ingresado caracteres invalidos.\n", "fuera de rango.\n", 3, 1, 150, &auxData4) == 0)
                {
                    if(gedata_getStrNumbr(auxData3, MAX_CHARS_DNI, "Ingrese el Nro de DNI: ", "Ha ingresado caracteres no validos.", MAX_INTENTOS_REINGRESOS) == 0)
                    {
                        asoc_loadData(nombre_array, length, auxData1, auxData2, auxData3, auxData4);
                        retorno = 0;
                    }//printf("ErrorMsg: supero cantidad de intentos DNI\n");
                }//printf("ErrorMsg: supero cantidad de intentos edad\n");
            }//printf("ErrorMsg: supero cantidad de intentos apellido\n");
        }//printf("ErrorMsg: supero cantidad de intentos nombre\n");
        getdata_continuar("desea continuar? S/N: ", "Ha ingresado una opcion no valida. intente nuevamente: ", MAX_INTENTOS_REINGRESOS, &respuesta);
        i++;
    } while (respuesta != 'n' && i < length);

    return retorno;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
