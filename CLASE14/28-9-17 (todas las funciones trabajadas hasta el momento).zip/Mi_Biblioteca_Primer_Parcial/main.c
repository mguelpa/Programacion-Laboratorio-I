#include <stdio.h>
#include <stdlib.h>

#include "controller.h"
#include "validate.h"

#define MAX_CANTIDAD_ADHERENTES 10
#define MAX_CANTIDAD_INCIDENTES 100

int main()
{
    //Se crea el array de abonados y se inicializa
    sAsociados adheridos[MAX_CANTIDAD_ADHERENTES];
    asociados_arrayInit(adheridos, MAX_CANTIDAD_ADHERENTES);

    //Se crea el array de Llamadas y se inicializa
    sLLamados incidentes[MAX_CANTIDAD_INCIDENTES];
    llamados_arrayInit(incidentes, MAX_CANTIDAD_INCIDENTES);

    //Carga datos de test
    controller_mock(arrayLlamadas, LLAMADAS_CANTIDAD,arrayAbonados,ABONADOS_CANTIDAD);


    int opcion;

    do
    {
        system("cls");

        printf("1- ALTA ASOCIADO\n");
        printf("2- MODIFICAR DATOS ASOCIADO\n");
        printf("3- BAJA DE ASCIADO\n");
        printf("4- REGISTRAR LLAMADA\n");
        printf("5- FINALIZAR LLAMADA\n");
        printf("6- INFORME\n");
        printf("7- LISTAR LLAMADAS\n");
        printf("8- LISTAR ASOCIADOS\n");

        printf("9- Salir\n");

        opcion = 0;
        getdata_getInt("ingrese un numero: ", "ha ingresado caracteres invalidos.\n", "fuera de rango.\n", 3, 1, 9, &numero);

        switch(opcion)
        {

            case 1: //ALTA ASOCIADO
                controller_loadAsociado (adheridos, MAX_CANTIDAD_ADHERIDOS);
                break;

            case 2: //MODIFICAR DATOS ASOCIADO
                break;

            case 3: //BAJA DE ASCIADO
                break;

            case 4: //REGISTRAR LLAMADA
                break;

            case 5: //FINALIZAR LLAMADA
                break;

            case 6: //INFORME
                break;

            case 7: //LISTAR LLAMADAS
                break;

            case 8: //LISTAR ASOCIADOS
                break;

            case 9:
                seguir = 'n';
                break;
        }

    }while(opcion != 9);

    return 0;
}