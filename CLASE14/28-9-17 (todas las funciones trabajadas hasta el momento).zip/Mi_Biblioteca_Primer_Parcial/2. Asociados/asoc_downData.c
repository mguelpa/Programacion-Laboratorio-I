///////////////////////////////////////////////////////////
int asoc_downData (sNombre_struct* nombre_array, int length, int id)
{
    int retorno = -1;
    int index;

    if(nombre_array != NULL && length > 0)
    {
        index = asoc_searchIndexById(nombre_array, length, id);
        
        if(index != -1){
            nombre_array[index].status = STATUS_DOWN;
            retorno = 0;
        }
        else{
            printf("error: busqueda de retorno = -1");
        }
    }
    return retorno;
}
///////////////////////////////////////////////////////////
