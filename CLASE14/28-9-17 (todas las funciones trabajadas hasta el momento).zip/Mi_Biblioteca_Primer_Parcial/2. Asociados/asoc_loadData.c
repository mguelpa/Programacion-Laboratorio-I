#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "asociado.h"

#define STATUS_EMPTY 0
#define STATUS_LOADED 1
#define STATUS_DOWN -1

typedef struct
{
    unsigned int id;
    unsigned int status; //(STATUS_EMPTY 0) (STATUS_LOADED 1) (STATUS_DOWN -1)

    char nombre[51];
    char apellido[51];
    int  edad;
    char dni[51];

}sAsociados;

///////////////////////////////////////////////////////////////////////////////
int asoc_loadData (sNombre_struct* nombre_array, int length, char* data1, char* data2, char* data3, int* data4)
{
	int retorno = -1;
	unsigned int id;
	int index = 0;

	if(nombre_array != NULL && length > 0)
    {
		index = asoc_searchEmptySlot(nomnre_array, length);
    	if(index != -1)
    	{
            nombre_array[index].status = STATUS_LOADED; 					 //(nombre_array +index)->status = STATUS_LOADED;
            nombre_array[index].id = id;                					 //(nombre_array +index)->id = id;

            strncpy(nombre_array[index].nombre, data1, MAX_CHARS_NOMBRES);   //strncpy((nombre_array +index)->nombre, auxData1, MAX_CHARS_NOMBRES); 
            strncpy(nombre_array[index].apellido, data2, MAX_CHARS_NOMBRES); //strncpy((nombre_array +index)->apellido, auxData1, MAX_CHARS_NOMBRES);
            nombre_array[index].edad = data4;								 //strncpy((nombre_array +index)->edad = auxData1;
            strncpy(nombre_array[index].dni, data3, MAX_CHARS_DNI);          //strncpy((nombre_array +index)->dni, auxData1, MAX_CHARS_DNI);
			retorno = 0;
		}		
	}
	return retorno;
}
///////////////////////////////////////////////////////////////////////////////