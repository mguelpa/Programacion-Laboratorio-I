////////////////////////////////////////////////////////////////////////////////////
int asoc_searchIndexById (sNombre_struct* nombre_array, int length, unsigned int id)
{
    int retorno = -1;
    int index;

    if(nombre_array != NULL && longitud > 0 && id >= 0)
    {
        for(index = 0; i<length; i++)
        {
            if(nombre_array[i].status == STATUS_LOADED)
            {
                if(id == nombre_array[i].id)
                {
                    retorno = index;
                    break;
                }
            }
        }
    }
    return retorno;
}
////////////////////////////////////////////////////////////////////////////////////