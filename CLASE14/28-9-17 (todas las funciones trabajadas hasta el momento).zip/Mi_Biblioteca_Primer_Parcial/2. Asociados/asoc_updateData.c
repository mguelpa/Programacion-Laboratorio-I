int asociados_updateData (sNombre_struct* nombre_array, int length, int id, char* data1, char* data2, char* data3, int* data4)
{
	int retorno = -1;
	int index;

	if(nombre_array != NULL && length > 0)
    {
		index = asoc_searchIndexById(nombre_array, length, id);
    	if(index != -1)
    	{
            strncpy(nombre_array[index].nombre, data1, MAX_CHARS_NOMBRES);   //strncpy((nombre_array +index)->nombre, auxData1, MAX_CHARS_NOMBRES); 
            strncpy(nombre_array[index].apellido, data2, MAX_CHARS_NOMBRES); //strncpy((nombre_array +index)->apellido, auxData1, MAX_CHARS_NOMBRES);
            nombre_array[index].edad = data4;								 //strncpy((nombre_array +index)->edad = auxData1;
            strncpy(nombre_array[index].dni, data3, MAX_CHARS_DNI);          //strncpy((nombre_array +index)->dni, auxData1, MAX_CHARS_DNI);
			retorno = 0;
		}
	}
	return retorno;
}