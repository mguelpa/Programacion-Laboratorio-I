/** 
 * \brief  Se marcan todas las posiciones del array como libres
 *          colocando en cada elmento STATUS_EMPTY
 *
 * \param sStruct* nombre_array Puntero al array 
 * \param length int Longitud del array
 * \return int Return (-1) si hay un Error [Longitud invalida o puntero NULL] 
 * 					  ( 0) si Ok
 */
	int struct_arrayInit (sStruct* nombre_array, int length)
	{
		int retorno = -1;
	    int i;

	    if(nombre_array != NULL && length > 0){
		    for(i=0; i<length; i++)
		    {
		        nombre_array[i].status = STATUS_EMPTY;
		        //nombre_array[i].callStatus = STATUS_EMPTY;
	            //nombre_array[i].incidentStatus = STATUS_EMPTY;
	            	//(nombre_array+i)->callStatus = STATUS_EMPTY;

	   	        //nombre_array[i].id = STATUS_EMPTY;
	            //nombre_array[i].idLLamada = STATUS_EMPTY;
	            //nombre_array[i].idAbonado = STATUS_EMPTY;
		        retorno = 0;
		    }
		}
	    return retorno;
	}
	////////////////////////////////////////////////////////////////////////////////////////////////////
