#ifndef ASOCIADOS_H_INCLUDED
#define ASOCIADOS_H_INCLUDED
#define MAX_ELEMENTOS_ARRAY 5
#define MAX_INCIDENTES 5
#define MAX_INTENTOS_REINGRESOS 3

#define MAX_INPUT_BUFFER 4096

#define MAX_CHARS_NOMBRE 51
#define MAX_CHARS_APELLIDO 51
#define MAX_CHARS_EDAD 5
#define MAX_CHARS_ID 51
#define MAX_CHARS_DNI 51

    #define STATUS_EMPTY 0
    #define STATUS_LOADED 1
    #define STATUS_DOWN -1

    typedef struct
    {
        unsigned int id;
        unsigned int status; //(STATUS_EMPTY 0) (STATUS_LOADED 1) (STATUS_DOWN -1)

        char nombre[51];
        char apellido[51];
        int  edad;
        char dni[51];

    }sAsociados;

#endif // ASOCIADOS_H_INCLUDED

int asociados_arrayInit (sAsociados* nombre_array, int length);
int asociados_loadSlots (sAsociados* nombre_array, int length);
int asociados_searchEmptySlot (sAsociados* nombre_array, int length);
int asociados_generateID (sAsociados* nombre_array, int length);
int asociados_searchIndexById (sAsociados* nombre_array, int length, unsigned int id);

