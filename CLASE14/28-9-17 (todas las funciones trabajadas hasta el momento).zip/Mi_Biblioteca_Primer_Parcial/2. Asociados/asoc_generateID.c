#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "asociado.h"

#define STATUS_EMPTY 0
#define STATUS_LOADED 1
#define STATUS_DOWN -1

typedef struct
{
    unsigned int id;
    unsigned int status; //(STATUS_EMPTY 0) (STATUS_LOADED 1) (STATUS_DOWN -1)

    char nombre[51];
    char apellido[51];
    int  edad;
    char dni[51];

}sAsociados;

///////////////////////////////////////////////////////////
int struct_generateID (sStruct* Nombre_array, int length)
{
    int nextID = 1;
    int i;

    if(Nombre_array != NULL && length > 0)
    {
        for(i=0; i<length; i++)
        {
            if(Nombre_array[i].status == STATUS_LOADED || Nombre_array[i].status == STATUS_DOWN)
            {
                if(nextID < Nombre_array[i].id){
                   nextID = Nombre_array[i].id + 1;
                }
            }
        }
    }else{nextID = -1;}
    
    return nextID;
}
///////////////////////////////////////////////////////////