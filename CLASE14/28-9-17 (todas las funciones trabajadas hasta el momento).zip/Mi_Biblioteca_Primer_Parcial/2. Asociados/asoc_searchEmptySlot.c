#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "asociado.h"

#define STATUS_EMPTY 0
#define STATUS_LOADED 1
#define STATUS_DOWN -1

typedef struct
{
    unsigned int id;
    unsigned int status; //(STATUS_EMPTY 0) (STATUS_LOADED 1) (STATUS_DOWN -1)

    char nombre[51];
    char apellido[51];
    int  edad;
    char dni[51];

}sAsociados;

///////////////////////////////////////////////////////////////////////////////////////////////////
int struct_searchEmptySlot (sNombre_struct* nombre_array, int length)
{
    int retorno = -1;
    int index;

    if(nombre_array != NULL && length > 0){

        for(index = 0; index < length; index++)
        {
            if(nombre_array[i].status == STATUS_EMPTY){
                retorno =  index;
                break;
            }
        }
    }
    return retorno;
}
///////////////////////////////////////////////////////////////////////////////////////////////////