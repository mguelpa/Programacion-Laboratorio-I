#ifndef LLAMADOS_H_INCLUDED
#define LLAMADOS_H_INCLUDED

    #define CALL_EMPTY 0
    #define CALL_TAKEN 1

    #define CAUSA_ACV 1
    #define CAUSA_INFARTO 2
    #define CAUSA_GRIPE 3

    #define INCIDENT_EMPTY 0
    #define INCIDENT_PENDING 1
    #define INCIDENT_INPROGRESS 2
    #define INCIDENT_SOLVED 3

    typedef struct{
        unsigned int idLLamada;
        unsigned int idAbonado;

        int callStatus;     //(STATUS_EMPTY 0) (STATUS_LOADED 1)
        int incidentStatus; //(INCIDENT_PENDING 0) (INCIDENT_INPROGRESS 1) (INCIDENT_SOLVED 2)

        int motivo;         //(ACV 1) (INFARTO 2) (GRIPE 3)

      //int hora[2];
    }sLLamados;

#endif // LLAMADOS_H_INCLUDED

int llamados_arrayInit (sLLamados* nombre_array, int length);

