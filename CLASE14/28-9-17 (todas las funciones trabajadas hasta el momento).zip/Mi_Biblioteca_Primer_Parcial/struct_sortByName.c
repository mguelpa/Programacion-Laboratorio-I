/********************************************************************
 * \brief   Funcion utilizada para ordenar por nombre alfaeticamente
 *          el array.
 *
 * \param   1. Puntero al array a ordenar.
 * \param   2. Limite del array.
 *
 * \return  ( 0) =  ordenamiento de por lo menos un dato.
 * \return  (-1) =  aun no se han cargado datos.
 *
 */
    int struct_sortByName (sNombre_struct* nombre_array, int length)
    {
        int i;
        int j;
        int retorno;
        sPersona auxiliar;

        for(i = 0; i< length -1; i++)
        {
            if(nombre_array[i].status == STATUS_LOADED)
            {
                for(j = i +1; j< length; j++)
                {
                    if(strcmp(nombre_array[i].nombre, nombre_array[j].nombre) > 0)
                    {
                        auxiliar = nombre_array[i];
                        nombre_array[i] = nombre_array[j];
                        nombre_array[i] = auxiliar;
                        retorno = 0;
                    }
                }
            }else{retorno = -1;}
        }
        return retorno;
    }