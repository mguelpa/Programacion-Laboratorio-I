#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>



int main()
{
    int numero = 0;

    getInt("ingrese un numero: ", "ha ingresado caracteres invalidos.\n", "fuera de rango.\n", 3, -10, 10, &numero);

    printf("%d", numero);
    return 0;
}
////////////////////////////////////////////////////////////////////////////////////////////////////
int interface_getInt(char* request, char* errorMsg, char* errorMsg2, int attemps, int min, int max, int* target)
{
    int retorno = -1;

    char auxStrNum[256];
    int  auxInt;

    int  i;

    for(i = 0; i<attemps; i++)
    {
        if (!interface_getNumericStr(request, auxStrNum))
        {
            printf(errorMsg);
            break;
            continue;
        }

        auxInt = atoi (auxStrNum);

        if(auxInt > max || auxInt < min)
        {
            printf (errorMsg2);
            continue;

        }

        *target = auxInt;
        retorno = 0;
        break;
    }
    return retorno;
}
////////////////////////////////////////////////////////////////////////////////////////////////////
int interface_getNumericStr (char* request, char* target)
{
    char aux[256];

    interface_fgetsSwitchLF(request, aux, 256, stdin);

    if(validate_verifyStrNumbr(aux))
    {
        strcpy(target, aux);
        return 1;
    }
    return 0;
}
////////////////////////////////////////////////////////////////////////////////////////////////////
int validate_verifyStrNumbr (char* buffer)
{
    int retorno = 1;
    int i = 0;

    while(buffer[i] != '\0')
    {
        if((buffer[i] < '0' || buffer[i] > '9') && buffer[i] != '-')
        {
            retorno = 1;
            break;
        }
        else
        {
            if(i != 0 && buffer[i] == '-')
            {
                retorno = 1;
                break;
            }
        }
        i++;
    }
    return retorno;
}
////////////////////////////////////////////////////////////////////////////////////////////////////
void interface_fgetsSwitchLF (char* request, char* targetStr, int length, FILE* fileName)
{
    int i = 0;

    printf(request);
    fflush(stdin);

    fgets(targetStr, length, fileName);
    targetStr[length-1] = '\0'; //---> ultimo indice de array (tamaño 10; indice 0 - 9)

    while(targetStr[i] != '\0')
    {
        if(targetStr[i] == 10){
            targetStr[i] = '\0'; //---> LF switch
            break;
        }
        i++;
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////
