////////////////////////////////////////////////////////////////////////////////////////////////////
void interface_fgetsSwitchLF (char* request, char* targetStr, int length, FILE* fileName)
{
    int i = 0;

    printf(request);
    fflush(stdin);

    fgets(targetStr, length, fileName);
    targetStr[length-1] = '\0'; //---> ultimo indice de array (tamaño 10; indice 0 - 9)

    while(targetStr[i] != '\0')
    {
        if(targetStr[i] == 10){
            targetStr[i] = '\0'; //---> LF switch
            break;
        }
        i++;
    }
}
///////////////////////////////////////////////////////////////////////////////////////////////////
