#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


int main()
{
    char nombre[50];

    getNames("ingrese un nombre: ", "ha ingresado caracteres invalidos.\n", "fuera de rango.\n", 3, 5, 2, nombre);

    printf("%s", nombre);
    return 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
int interface_getNames(char* request, char* errorMsg, char* errorMsg2, int attemps, int min, int max, char* target)
{
    int retorno = -1;

    char auxStrNames[1024];
    int  i;

    for(i = 0; i<attemps; i++)
    {
        if (!interface_getAlfabeticStr(request, auxStrNames))
        {
            printf(errorMsg);
            break;
            continue;
        }

        if(strlen(auxStrNames) > max || strlen(auxStrNames) < min)
        {
            printf (errorMsg2);
            continue;
        }

        strcpy(target, auxStrNames);
        retorno = 0;
        break;
    }
    return retorno;
}
////////////////////////////////////////////////////////////////////////////////////////////////////
int interface_getAlfabeticStr (char* request, char* input)
{
    char aux[1024];

    interface_fgetsSwitchLF(request, aux, 1024, stdin);

    if(validate_verifyStrName(aux))
    {
        strcpy(input, aux);
        return 1;
    }
    return 0;
}
////////////////////////////////////////////////////////////////////////////////////////////////////
int validate_verifyStrName (char* buffer)
{
   int i = 0;
   while(buffer[i] != '\0')
   {
       if((buffer[i] < 'a' || buffer[i] > 'z') && (buffer[i] < 'A' || buffer[i] > 'Z'))
           return 0;
       i++;
   }
   return 1;
}
////////////////////////////////////////////////////////////////////////////////////////////////////
void fgetsSwitchLF (char* request, char* targetStr, int length, FILE* fileName)
{
    int i = 0;

    printf(request);
    fflush(stdin);

    fgets(targetStr, length, fileName);
    targetStr[length-1] = '\0'; //---> ultimo indice de array (tamaño 10; indice 0 - 9)

    while(targetStr[i] != '\0')
    {
        if(targetStr[i] == 10){
            targetStr[i] = '\0'; //---> LF switch
            break;
        }
        i++;
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////