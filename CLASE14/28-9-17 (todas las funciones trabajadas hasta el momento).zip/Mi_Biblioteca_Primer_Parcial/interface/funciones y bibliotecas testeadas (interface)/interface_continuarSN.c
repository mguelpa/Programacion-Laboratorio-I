#include <stdio.h>
#include <stdlib.h>

#include <ctype.h>
int continuar(char* solicitud, char* msjIntentos, int intentos, char* buffer);

int main()
{
    char letra;
    int retorno;

    retorno = continuar("desea continuar? S/N: ", "Ha ingresado una opcion no valida. intente nuevamente: ", 3, &letra);

    printf("\n%c", letra);
    printf("\n%d", retorno);

    return 0;
}

/*****************************************************************************
 * \brief 	Funcion usada para preguntar al usuario si desea "continuar"
 *              - Chequea que solo sean admitidas las letras "s" o "n".
 *              - utiliza funcion tolower contenida en <ctype.h>
 *
 * \param       1. pregunta al usuario
 * \param       2. mensaje Error max intentos
 * \param       3. cantidad de intentos
 * \param       4. variable donde cargar la letra ingresada correctamente
 *
 * \return      (0) letra cargada correctamente (-1) supero cantidad intentos
 */
///////////////////////////////////////////////////////////////////////////////////////////////////
int interface_continuar(char* solicitud, char* msjIntentos, int intentos, char* buffer)
{
    char aux;
    printf(solicitud);
    fflush(stdin);
    aux = tolower(getchar());
    while(!(aux == 's' || aux == 'n'))
    {
        printf(msjIntentos);
        fflush(stdin);
        aux = tolower(getchar());
        intentos--;
        if(intentos < 1){
            *buffer = 'n';
            return -1;
        }
    }
    *buffer = aux;
    return 0;
}
////////////////////////////////////////////////////////////////////////////////////////////////////
