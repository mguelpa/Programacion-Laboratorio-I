////////////////////////////////////////////////////////////////////////////////////////////////////
int validate_verifyStrNumbr (char* buffer)
{
    int retorno = 1;
    int i = 0;

    while(buffer[i] != '\0')
    {
        if((buffer[i] < '0' || buffer[i] > '9') && buffer[i] != '-')
        {
            retorno = 1;
            break;
        }
        else
        {
            if(i != 0 && buffer[i] == '-')
            {
                retorno = 1;
                break;
            }
        }
        i++;
    }
    return retorno;
}
////////////////////////////////////////////////////////////////////////////////////////////////////