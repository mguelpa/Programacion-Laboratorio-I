int validate_verifyFloat(char* buffer)
{
    int retorno = 0;
    int i=0;
    int flagPunto = 0;

    while(buffer[i] != '\0')
    {
        if((buffer[i] < '0' || buffer[i] > '9') && buffer[i] != '.' && buffer[i] != '-' )
        {
            retorno = -1;
            break;
        }
        else
        {
            if(i != 0 && buffer[i] == '-')
            {
                retorno = -2;
                break;
            }
            else if(buffer[i] == '.')
            {
                flagPunto++;
                if(flagPunto > 1){
                    retorno = -3;
                    break;
                }
            }
        }
        i++;
    }
    return retorno;
}