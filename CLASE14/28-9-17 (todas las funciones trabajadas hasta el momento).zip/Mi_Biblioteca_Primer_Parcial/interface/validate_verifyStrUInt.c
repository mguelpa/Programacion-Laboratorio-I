int validate_verifyStrUInt (char* strUnsignedInt)
{
	int retorno = 0;
	int i = 0;

    while(strUnsignedInt[i] != '\0')
    {
        if(strUnsignedInt[i] < '0' || strUnsignedInt[i] > '9'){
            retorno = -1;
            break;
        }
        i++;
    }
	return retorno;
}