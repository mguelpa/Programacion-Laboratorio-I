/**
 * \brief   Funcion utilizada para verificar el ingreso de edades en forma de 
 *          string de chars que este dentro del rango especificado.
 *              - utiliza funcion atoi(); contenida en <string.h>
 *
 * \param       1. string array a analizar.
 *
 * \return      (0) Edad Valida (-1) caracteres no admitidos
 *                              (-2) edad fuera de rango
 */
//////////////////////////////////////////////////////////////////////////////
int validate_verfyStrAge (char* strAge)
{
    int retorno = 0;
    int i = 0;

    while(strAge[i] != '\0')
    {
        if(strAge[i] < '0' || strAge[i] > '9'){
            return -1;
        }
        i++;
    }
    if(atoi(strAge) > MAX_EDAD_ADMITIDA || atoi(strAge) < MIN_EDAD_ADMITIDA){
        retorno = -2;
    }
    return retorno;
}
/////////////////////////////////////////////////////////////////////////////