int interface_getData (char* target, int length, char* request, char* errorMsg, int attempts)
{
	int retorno = -1;
	char bufferData[length];

	if(target != NULL && length > 0 && length < MAX_INPUT_BUFFER)
    {
    	printf(request);

    	while(attempts > 0)
    	{
    		fflush(stdin);
    		fgetsSwitchLF(bufferData, length, stdin);

            switch(validate_verfyStr(bufferData)) //validate_verfyStrName(), validate_verfyStrEdad(), etc.     ---> cambiar segun tipo de dato solicitado
            {
                // case -2: ---> se aregaran cases dependiendo de la cantidad de retornos
                //     printf(errorMsg1);
                //     retorno = -2;
                //     break;

                case -1:
                    printf(errorMsg);
                    retorno = -1;
                    break;

                case  0:
                    strncpy(target, bufferData, length);
                    retorno = 0;
                    break;

                default:
                    printf("errorMsg: error indefinido\n");
                    break;

            }if(retorno == 0){
                break;
            }else{attempts--;}    
   	    }
    }
	return retorno;
}
