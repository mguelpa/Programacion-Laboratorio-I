#include <stdio.h>
#include <stdlib.h>

#include <ctype.h>
int verificaSN(char* buffer);

int main()
{
    char letra;
    int retorno;

    printf("Ingrese S/N: ");
    fflush(stdin);
    letra = getchar();
    retorno = continuar(&letra);

    printf("\nchar letra: %c\tASCII: %d\n", letra, letra);
    printf("\nretorno: %d", retorno);

    return 0;
}

/********************************************************************************
 * \brief 	Funcion usada para preguntar al usuario si desea "continuar"
 *              - Chequea que solo sean admitidas las letras "s" o "n".
 *              - utiliza funcion tolower contenida en <ctype.h>
 *
 * \param       1. pregunta al usuario
 * \param       2. mensaje Error max intentos
 * \param       3. cantidad de intentos
 * \param       4. variable donde cargar la letra ingresada correctamente
 *
 * \return      (0) letra cargada correctamente (-1) supero cantidad intentos
 */
    int verificaSN(char* buffer)
    {
        char aux;
        //int retorno = -1;

        aux = tolower(*buffer);
        if(!(aux == 's' || aux == 'n'))
        {
            *buffer = '\0';
            return -1;
        }
        else
        {
            *buffer = aux;
            return 0;
        }

    }