#include <stdio.h>
#include <stdlib.h>

int obtenerFloat(char* mensaje, float* numero);

int main()
{
    float numero1 = 0;
    int retorno = 0;

    retorno = obtenerFloat("ingrese un numero: ", &numero1);
    printf("retorno: %d\n", retorno);
    printf("numero8: %f\n", numero1);

    return 0;
}

/*******************************************************************
 *          FUNCION: OBTENER FLOAT
 *
 * \brief   Funcion utilizada para solicitar un numero float. la
 *          funcion toma un string y valida la entrada de signos 
 *          negativos x1, puntos x1, ingreso de (-0) cambia a posit. 
 *          comas y espacios no son admitidos. El string es conver-
 *          tido a float con atof() contenida en <string.h>
 *
 * \param   1. solicitud a ser mostrada
 * \param   2. puntero a la variable a ser cargada con un float
 *
 * \return  ( 0) =  conversion exitosa
 *          (-1) =  caracteres no validos
 *          (-2) =  doble ingreso de signo o punto.
 *          (-3) =  ingresa 0 o -0
 */
    int obtenerFloat(char* mensaje, float* numero)
    {
        int contadorGuiones = 0, contadorPuntos = 0;
        char str[20];
        int retorno;
        int i=0;

        printf("%s", mensaje);
        fflush(stdin);
        gets(str);

        while(str[i] != '\0')
        {
            if((str[i] != '-') && (str[i] != '.') && (str[i] < '0' || str[i] > '9'))
                return -1;
            if(str[i] == '-')
                contadorGuiones++;
            else if(str[i] == '.')
            {
                contadorPuntos++;
            }
            i++;
        }
        if(contadorGuiones >= 2 || contadorPuntos >= 2)
            retorno = -2;
        else
        {
            if(atof(str) == 0)
            {
                *numero = 0;
                retorno = -3;
            }
            else
            {
                *numero = atof(str);
                retorno = 0;
            }
        }
        return retorno;
    }