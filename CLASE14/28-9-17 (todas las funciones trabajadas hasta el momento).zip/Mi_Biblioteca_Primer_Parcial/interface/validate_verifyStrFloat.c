#include <stdio.h>
#include <stdlib.h>

int esFloat(char* str);

int main()
{
    int retorno;

    char numero1[] = "1,5";
    char numero2[] = "1.5";
    char numero3[] = "-1,5";
    char numero4[] = "-1.5";

    char numero5[] = "1,,5";
    char numero6[] = "1..5";
    char numero7[] = "-1,,5";
    char numero8[] = "-1..5";

    char numero9[] = "--1,5";
    char numero10[] = "--1.5";

    char numero11[] = "--1,,5";
    char numero12[] = "--1..5";
    char numero13[] = "1 ,5";
    char numero14[] = " 1,5";

    char numero15[] = "-0";
    char numero16[] = "0";

    char numero17[] = "1";
    char numero18[] = "-1";
    char numero19[] = "--1";
    char numero20[] = "b";

    char numero21[5];

    printf("ingrese un numero: ");
    fgets(numero21, 5, stdin);

    printf("ES FLOAT\n");
    printf("( 0) =  numero valido.\n");
    printf("(-1) =  ingreso caracteres no validos.\n");
    printf("(-2) =  doble ingreso de signo o coma.\n");
    printf("(-3) =  ingresa 0 o -0.\n\n");

    retorno = esFloat(numero1);
    printf("string: %s \tretorno: %d\n", numero1, retorno);
    retorno = esFloat(numero2);
    printf("string: %s \tretorno: %d\n", numero2, retorno);
    retorno = esFloat(numero3);
    printf("string: %s \tretorno: %d\n", numero3, retorno);
    retorno = esFloat(numero4);
    printf("string: %s \tretorno: %d\n", numero4, retorno);
    retorno = esFloat(numero5);
    printf("string: %s \tretorno: %d\n", numero5, retorno);
    retorno = esFloat(numero6);
    printf("string: %s \tretorno: %d\n", numero6, retorno);
    retorno = esFloat(numero7);
    printf("string: %s \tretorno: %d\n", numero7, retorno);
    retorno = esFloat(numero8);
    printf("string: %s \tretorno: %d\n", numero8, retorno);
    retorno = esFloat(numero9);
    printf("string: %s \tretorno: %d\n", numero9, retorno);
    retorno = esFloat(numero10);
    printf("string: %s \tretorno: %d\n", numero10, retorno);
    retorno = esFloat(numero11);
    printf("string: %s \tretorno: %d\n", numero11, retorno);
    retorno = esFloat(numero12);
    printf("string: %s \tretorno: %d\n", numero12, retorno);
    retorno = esFloat(numero13);
    printf("string: %s \tretorno: %d\n", numero13, retorno);
    retorno = esFloat(numero14);
    printf("string: %s \tretorno: %d\n", numero14, retorno);
    retorno = esFloat(numero15);
    printf("string: %s \tretorno: %d\n", numero15, retorno);
    retorno = esFloat(numero16);
    printf("string: %s \tretorno: %d\n", numero16, retorno);
    retorno = esFloat(numero17);
    printf("string: %s \tretorno: %d\n", numero17, retorno);
    retorno = esFloat(numero18);
    printf("string: %s \tretorno: %d\n", numero18, retorno);
    retorno = esFloat(numero19);
    printf("string: %s \tretorno: %d\n", numero19, retorno);
    retorno = esFloat(numero20);
    printf("string: %s \tretorno: %d\n", numero20, retorno);
    retorno = esFloat(numero21);
    printf("string: %s \tretorno: %d\n", numero21, retorno);

    return 0;
}
/*******************************************************************
*          FUNCION: VERIFICAR float
*
* \brief   Funcion utilizada para verifcar un numero decimal con
*          separador "coma". la funcion toma un string y valida la-
*          entrada de signos negativos x1, comas x1. puntos y espa-
*          acios no son admitidos. El string es convertido a float-
*          con atof() contenida en <string.h>
*
* \param   1. puntero a la variable con el strng a validar
*
* \return  ( 0) =  numero valido
*          (-1) =  ingreso caracteres no validos
*          (-2) =  doble ingreso de signo o coma.
*          (-3) =  ingresa 0 o -0
*/
    int esFloat(char* str)
    {
        int i = 0;
        int contadorGuiones = 0, contadorPuntos = 0;
        int retorno;

        while(str[i] != '\0')
        {
            if((str[i] != '-') && (str[i] != '.') && (str[i] < '0' || str[i] > '9'))
                return -1;
            if(str[i] == '-')
                contadorGuiones++;
            else if(str[i] == '.')
                contadorPuntos++;
            i++;
        }
        if(contadorGuiones >= 2 || contadorPuntos >= 2)
            retorno = -2;
        else
        {
            if(atof(str) == 0)
            {
                retorno = -3;
            }
            else
            {
                retorno = 0;
            }
        }
        return retorno;
    }
