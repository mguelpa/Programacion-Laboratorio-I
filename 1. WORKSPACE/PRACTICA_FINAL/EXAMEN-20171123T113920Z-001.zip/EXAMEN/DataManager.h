#ifndef DATAMANAGER_H_INCLUDED
#define DATAMANAGER_H_INCLUDED


int dm_dumpEmployeeList(ArrayList* list);

#endif // DATAMANAGER_H_INCLUDED
