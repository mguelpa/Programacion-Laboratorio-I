#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "Employee.h"


int parserEmployee(ArrayList* pArrayListEmployee)
{

    return 0;
}
