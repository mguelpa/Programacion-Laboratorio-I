#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "Employee.h"




Employee* employee_new(void)
{
    return NULL;
}

void employee_delete(Employee* this)
{


}

void employee_print(Employee* this)
{

}

int employee_filterEmployee(void* item)
{


    return 0;
}




