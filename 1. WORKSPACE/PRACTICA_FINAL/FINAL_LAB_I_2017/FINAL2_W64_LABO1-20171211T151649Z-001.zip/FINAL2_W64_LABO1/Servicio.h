#ifndef SERVICIO_H_INCLUDED
#define SERVICIO_H_INCLUDED

typedef struct
{
    int id;
}Servicio;

Servicio* serv_new(int id);

#endif // SERVICIO_H_INCLUDED
