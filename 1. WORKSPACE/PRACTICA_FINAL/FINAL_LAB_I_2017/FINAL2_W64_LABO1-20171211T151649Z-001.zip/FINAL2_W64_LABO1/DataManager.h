#define ARCHIVO_CLIENTES "clientes.bin"
#define ARCHIVO_SERVICIOS "servicios.bin"

int dm_saveAllClientes(ArrayList* pArraySocios);
int dm_readAllClientes(ArrayList* pArraySocios);
