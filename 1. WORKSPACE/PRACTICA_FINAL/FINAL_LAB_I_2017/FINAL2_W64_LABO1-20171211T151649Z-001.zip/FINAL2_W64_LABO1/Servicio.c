#include <stdio.h>
#include <stdlib.h>
#include "Servicio.h"


Servicio* serv_new(int id)
{
    return NULL;
}
