void cont_init();
int cont_altaX (char* a,char* b,int c);
int cont_bajaX (int id);
int cont_modificarX (int id, char* a,char* b,int c);
int cont_listarX ();
int cont_ordenarX ();



