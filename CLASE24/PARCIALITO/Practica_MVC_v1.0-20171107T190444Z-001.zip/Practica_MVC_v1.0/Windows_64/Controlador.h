

void cont_init();

int cont_altaSocio (char* nombre,char* apellido,char* dni);

int cont_bajaSocio (int);

int cont_modificarSocio (char* nombre,char* apellido,char* dni, int id, int estado);

int cont_listarSocios ();



